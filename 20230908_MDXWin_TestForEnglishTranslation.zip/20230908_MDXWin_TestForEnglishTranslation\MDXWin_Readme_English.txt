
       MDXWin 雑なMXDRVエミュレータ

       By Moonlight.

 ============================================================================

 * System requirements
 - OS     : Windows 10 or above
 - Runtime: .NET Desktop Runtime 7.0
 - Network: Internet with IPv6
 - DirectX: Version 12 or above

 * Introduction
 - MDXWin is an emulator that plays .MDX files on Windows.
 - MXDRV is an application of the music sequencer for X68k.
 - .MDX is a music file for MXDRV.
 - .PDX is an ADPCM package file used with MDX.

 * The .NET execution environment
 - https://dotnet.microsoft.com/en-us/download/dotnet/7.0
 - Download and install "Windows x64" in ".NET Desktop Runtime 7".

 History
 -------
 
2022/07/20
Start of development.

2023/xx/xx
Support English language little.

